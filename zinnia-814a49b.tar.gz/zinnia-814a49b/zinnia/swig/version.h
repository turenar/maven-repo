namespace zinnia {
#define VERSION "0.06"
}
