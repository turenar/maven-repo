//
//  Zinnia: Online hand recognition system with machine learning
//
//  $Id$;
//
//  Copyright(C) 2008 Taku Kudo <taku@chasen.org>
//
#include "zinnia.h"

int main(int argc, char** argv) {
  return zinnia_learn(argc, argv);
}
